DROP VIEW placed_migrants_view;
DROP TRIGGER place_workers;
DROP TABLE place_migrant;
DROP TABLE company_req;
DROP VIEW pjobloc_view;
DROP TABLE migrantw;
